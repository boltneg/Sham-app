export const COLORS = {
  // Primary Colors
  primary: '#1E40AF', // Deep Blue
  primaryLight: '#3B82F6', // Lighter Blue
  primaryDark: '#1E3A8A', // Darker Blue
  
  // Secondary Colors
  secondary: '#0F766E', // Teal
  secondaryLight: '#14B8A6', // Light Teal
  secondaryDark: '#115E59', // Dark Teal
  
  // Accent Colors
  accent: '#F97316', // Orange
  accentLight: '#FB923C', // Light Orange
  accentDark: '#C2410C', // Dark Orange
  
  // Feedback Colors
  success: '#10B981', // Green
  warning: '#F59E0B', // Amber
  error: '#EF4444', // Red
  
  // Neutrals
  white: '#FFFFFF',
  black: '#000000',
  textDark: '#1F2937', // For main text
  textLight: '#6B7280', // For secondary text
  border: '#E5E7EB',
  borderDark: '#374151',
  
  // Backgrounds
  background: '#F9FAFB', // Light background
  backgroundLight: '#F3F4F6', // Slightly darker background
  backgroundDark: '#111827', // Dark mode background
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const SIZES = {
  xxs: 10,
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 30,
  xxxxl: 36,
};

export const SHADOWS = {
  small: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  large: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
};