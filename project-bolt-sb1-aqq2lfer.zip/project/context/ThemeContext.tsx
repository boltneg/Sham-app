import { createContext, useState, useEffect, ReactNode } from 'react';
import { useColorScheme } from 'react-native';
import * as SecureStore from 'expo-secure-store';

interface ThemeContextType {
  darkMode: boolean;
  toggleDarkMode: () => void;
}

export const ThemeContext = createContext<ThemeContextType>({
  darkMode: false,
  toggleDarkMode: () => {},
});

interface ThemeProviderProps {
  children: ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  const systemColorScheme = useColorScheme();
  const [darkMode, setDarkMode] = useState(systemColorScheme === 'dark');
  
  useEffect(() => {
    // Load user preference from storage
    loadThemePreference();
  }, []);
  
  const loadThemePreference = async () => {
    try {
      const storedPreference = await SecureStore.getItemAsync('themePreference');
      
      if (storedPreference === null) {
        // No preference set, use system default
        setDarkMode(systemColorScheme === 'dark');
      } else {
        // Use stored preference
        setDarkMode(storedPreference === 'dark');
      }
    } catch (error) {
      console.error('Error loading theme preference:', error);
      // Fall back to system default
      setDarkMode(systemColorScheme === 'dark');
    }
  };
  
  const toggleDarkMode = () => {
    setDarkMode(prevMode => {
      const newMode = !prevMode;
      
      // Save preference to storage
      SecureStore.setItemAsync('themePreference', newMode ? 'dark' : 'light');
      
      return newMode;
    });
  };
  
  return (
    <ThemeContext.Provider value={{ darkMode, toggleDarkMode }}>
      {children}
    </ThemeContext.Provider>
  );
}