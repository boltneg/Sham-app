import * as FileSystem from 'expo-file-system';

// Function to read a JSON file
export async function readJSONFile(fileName: string, defaultValue: any = null) {
  try {
    const filePath = `${FileSystem.documentDirectory}${fileName}`;
    
    // Check if file exists
    const fileInfo = await FileSystem.getInfoAsync(filePath);
    if (!fileInfo.exists) {
      return defaultValue;
    }
    
    // Read file content
    const fileContent = await FileSystem.readAsStringAsync(filePath);
    return JSON.parse(fileContent);
  } catch (error) {
    console.error(`Error reading ${fileName}:`, error);
    return defaultValue;
  }
}

// Function to write a JSON file
export async function writeJSONFile(fileName: string, data: any) {
  try {
    const filePath = `${FileSystem.documentDirectory}${fileName}`;
    const jsonString = JSON.stringify(data, null, 2);
    await FileSystem.writeAsStringAsync(filePath, jsonString);
    return true;
  } catch (error) {
    console.error(`Error writing ${fileName}:`, error);
    return false;
  }
}

// Function to delete a file
export async function deleteFile(fileName: string) {
  try {
    const filePath = `${FileSystem.documentDirectory}${fileName}`;
    await FileSystem.deleteAsync(filePath);
    return true;
  } catch (error) {
    console.error(`Error deleting ${fileName}:`, error);
    return false;
  }
}

// Function to create directory if it doesn't exist
export async function ensureDirectoryExists(dirName: string) {
  try {
    const dirPath = `${FileSystem.documentDirectory}${dirName}`;
    const dirInfo = await FileSystem.getInfoAsync(dirPath);
    
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(dirPath, { intermediates: true });
    }
    
    return dirPath;
  } catch (error) {
    console.error(`Error creating directory ${dirName}:`, error);
    return null;
  }
}