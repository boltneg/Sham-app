import { useState, useEffect } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, TextInput, Modal, ActivityIndicator } from 'react-native';
import { useAuth } from '@/hooks/useAuth';
import { useData } from '@/hooks/useData';
import { Plus, Search, X, UserCheck, Edit, BookOpen } from 'lucide-react-native';
import { COLORS } from '@/constants/theme';
import FormButton from '@/components/FormButton';

export default function ClassesScreen() {
  const { userData } = useAuth();
  const { classes, subjects, updateUserClass, saveClass, saveSubject, isLoading } = useData();
  const [searchText, setSearchText] = useState('');
  const [filteredClasses, setFilteredClasses] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedClass, setSelectedClass] = useState(null);
  const [subjectModalVisible, setSubjectModalVisible] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newSubjectName, setNewSubjectName] = useState('');
  const [classSubjects, setClassSubjects] = useState([]);
  const [error, setError] = useState('');
  
  useEffect(() => {
    if (classes) {
      filterClasses();
    }
  }, [classes, searchText]);
  
  useEffect(() => {
    if (selectedClass) {
      const relatedSubjects = subjects.filter(subject => 
        subject.classIds.includes(selectedClass.id)
      );
      setClassSubjects(relatedSubjects);
    }
  }, [selectedClass, subjects]);
  
  const filterClasses = () => {
    if (!searchText) {
      setFilteredClasses(classes);
      return;
    }
    
    const filtered = classes.filter(classItem => 
      classItem.name.toLowerCase().includes(searchText.toLowerCase())
    );
    setFilteredClasses(filtered);
  };
  
  const handleSelectClass = async (classItem) => {
    if (userData.type === 'student') {
      // For students, update their class
      await updateUserClass(classItem.id);
    } else {
      // For teachers, show class details
      setSelectedClass(classItem);
      setModalVisible(true);
    }
  };
  
  const handleCreateClass = async () => {
    if (!newClassName) {
      setError('Please enter a class name');
      return;
    }
    
    try {
      await saveClass(newClassName);
      setNewClassName('');
      setError('');
      setModalVisible(false);
    } catch (err) {
      setError('Failed to create class');
      console.error(err);
    }
  };
  
  const handleCreateSubject = async () => {
    if (!newSubjectName) {
      setError('Please enter a subject name');
      return;
    }
    
    try {
      await saveSubject(newSubjectName, selectedClass.id);
      setNewSubjectName('');
      setError('');
      setSubjectModalVisible(false);
    } catch (err) {
      setError('Failed to create subject');
      console.error(err);
    }
  };
  
  const closeModal = () => {
    setModalVisible(false);
    setSelectedClass(null);
    setError('');
  };
  
  const closeSubjectModal = () => {
    setSubjectModalVisible(false);
    setError('');
  };
  
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Classes</Text>
        <Text style={styles.subtitle}>
          {userData.type === 'student' 
            ? 'Select your class to see relevant agendas' 
            : 'Manage classes and subjects'
          }
        </Text>
      </View>
      
      <View style={styles.searchContainer}>
        <Search size={20} color={COLORS.textLight} style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search classes..."
          value={searchText}
          onChangeText={setSearchText}
          placeholderTextColor={COLORS.textLight}
        />
        {searchText ? (
          <TouchableOpacity onPress={() => setSearchText('')}>
            <X size={20} color={COLORS.textLight} />
          </TouchableOpacity>
        ) : null}
      </View>
      
      {userData.type === 'teacher' && (
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => {
            setSelectedClass(null);
            setModalVisible(true);
          }}
        >
          <Plus size={20} color={COLORS.white} />
          <Text style={styles.addButtonText}>Create New Class</Text>
        </TouchableOpacity>
      )}
      
      <FlatList
        data={filteredClasses}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={[
              styles.classCard,
              userData.classId === item.id && styles.selectedClassCard
            ]}
            onPress={() => handleSelectClass(item)}
          >
            <View style={styles.classCardContent}>
              <View>
                <Text style={styles.className}>{item.name}</Text>
                <Text style={styles.classDetails}>
                  {subjects.filter(s => s.classIds.includes(item.id)).length} subjects
                </Text>
              </View>
              
              {userData.type === 'student' && userData.classId === item.id && (
                <View style={styles.selectedBadge}>
                  <UserCheck size={16} color={COLORS.white} />
                  <Text style={styles.selectedText}>Selected</Text>
                </View>
              )}
              
              {userData.type === 'teacher' && (
                <TouchableOpacity 
                  style={styles.editButton}
                  onPress={() => {
                    setSelectedClass(item);
                    setModalVisible(true);
                  }}
                >
                  <Edit size={16} color={COLORS.primary} />
                </TouchableOpacity>
              )}
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <BookOpen size={48} color={COLORS.textLight} />
            <Text style={styles.emptyStateText}>No classes found</Text>
            {userData.type === 'teacher' && (
              <Text style={styles.emptyStateSubtext}>Create your first class to get started</Text>
            )}
          </View>
        }
      />
      
      {/* Class Modal */}
      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={closeModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {selectedClass ? `Class: ${selectedClass.name}` : 'Create New Class'}
              </Text>
              <TouchableOpacity onPress={closeModal}>
                <X size={24} color={COLORS.textDark} />
              </TouchableOpacity>
            </View>
            
            {!selectedClass ? (
              <View style={styles.modalContent}>
                <Text style={styles.inputLabel}>Class Name</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter class name (e.g., Class 12A)"
                  value={newClassName}
                  onChangeText={setNewClassName}
                  placeholderTextColor={COLORS.textLight}
                />
                
                {error ? <Text style={styles.errorText}>{error}</Text> : null}
                
                <FormButton
                  onPress={handleCreateClass}
                  label="Create Class"
                />
              </View>
            ) : (
              <View style={styles.modalContent}>
                <Text style={styles.sectionTitle}>Subjects for {selectedClass.name}</Text>
                
                <FlatList
                  data={classSubjects}
                  keyExtractor={(item) => item.id}
                  style={styles.subjectsList}
                  renderItem={({ item }) => (
                    <View style={styles.subjectItem}>
                      <Text style={styles.subjectName}>{item.name}</Text>
                    </View>
                  )}
                  ListEmptyComponent={
                    <View style={styles.emptySubjects}>
                      <Text style={styles.emptySubjectsText}>No subjects added yet</Text>
                    </View>
                  }
                />
                
                <TouchableOpacity 
                  style={styles.addSubjectButton}
                  onPress={() => {
                    setSubjectModalVisible(true);
                  }}
                >
                  <Plus size={20} color={COLORS.white} />
                  <Text style={styles.addButtonText}>Add Subject</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </Modal>
      
      {/* Subject Modal */}
      <Modal
        visible={subjectModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={closeSubjectModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Subject</Text>
              <TouchableOpacity onPress={closeSubjectModal}>
                <X size={24} color={COLORS.textDark} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalContent}>
              <Text style={styles.inputLabel}>Subject Name</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter subject name (e.g., Mathematics)"
                value={newSubjectName}
                onChangeText={setNewSubjectName}
                placeholderTextColor={COLORS.textLight}
              />
              
              {error ? <Text style={styles.errorText}>{error}</Text> : null}
              
              <FormButton
                onPress={handleCreateSubject}
                label="Add Subject"
              />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
  },
  loadingText: {
    marginTop: 16,
    fontFamily: 'Inter-Medium',
    color: COLORS.textDark,
  },
  header: {
    padding: 16,
    paddingTop: 24,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: COLORS.textDark,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textLight,
    marginTop: 4,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    marginHorizontal: 16,
    borderRadius: 8,
    padding: 12,
    marginVertical: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textDark,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    borderRadius: 8,
    paddingVertical: 12,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  addButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.white,
    marginLeft: 8,
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  classCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    marginBottom: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  selectedClassCard: {
    borderColor: COLORS.primary,
    borderWidth: 2,
  },
  classCardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  className: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: COLORS.textDark,
  },
  classDetails: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 4,
  },
  selectedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 16,
  },
  selectedText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: COLORS.white,
    marginLeft: 4,
  },
  editButton: {
    padding: 8,
    borderRadius: 20,
    backgroundColor: COLORS.backgroundLight,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 48,
  },
  emptyStateText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginTop: 16,
  },
  emptyStateSubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 4,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    width: '90%',
    maxWidth: 500,
    backgroundColor: COLORS.white,
    borderRadius: 16,
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  modalTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: COLORS.textDark,
  },
  modalContent: {
    padding: 16,
  },
  inputLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginBottom: 8,
  },
  input: {
    backgroundColor: COLORS.backgroundLight,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textDark,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  errorText: {
    color: COLORS.error,
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    marginBottom: 16,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: COLORS.textDark,
    marginBottom: 12,
  },
  subjectsList: {
    maxHeight: 200,
    marginBottom: 16,
  },
  subjectItem: {
    padding: 12,
    backgroundColor: COLORS.backgroundLight,
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  subjectName: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
  },
  emptySubjects: {
    padding: 24,
    alignItems: 'center',
  },
  emptySubjectsText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.textLight,
  },
  addSubjectButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.secondary,
    borderRadius: 8,
    paddingVertical: 12,
  },
});