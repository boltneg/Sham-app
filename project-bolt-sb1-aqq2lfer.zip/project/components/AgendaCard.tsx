import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { Calendar, BookOpen, AlertCircle } from 'lucide-react-native';
import { COLORS, SHADOWS } from '@/constants/theme';

interface AgendaCardProps {
  title: string;
  description: string;
  dueDate: string;
  subject: string;
  className: string;
}

export default function AgendaCard({ title, description, dueDate, subject, className }: AgendaCardProps) {
  // Check if the due date is within the next 2 days
  const isUrgent = () => {
    const now = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 2 && diffDays >= 0;
  };

  // Format the due date nicely
  const formatDueDate = () => {
    const due = new Date(dueDate);
    return due.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  return (
    <View style={[styles.container, isUrgent() && styles.urgentContainer]}>
      {isUrgent() && (
        <View style={styles.urgentBadge}>
          <AlertCircle size={14} color={COLORS.white} />
          <Text style={styles.urgentText}>Due Soon</Text>
        </View>
      )}
      
      <Text style={styles.title}>{title}</Text>
      
      <View style={styles.detailsRow}>
        <View style={styles.detailItem}>
          <BookOpen size={16} color={COLORS.secondary} />
          <Text style={styles.detailText}>{subject}</Text>
        </View>
        
        <View style={styles.detailItem}>
          <Calendar size={16} color={isUrgent() ? COLORS.error : COLORS.accent} />
          <Text style={[styles.detailText, isUrgent() && styles.urgentDate]}>
            {formatDueDate()}
          </Text>
        </View>
      </View>
      
      <Text style={styles.className}>{className}</Text>
      
      <Text style={styles.description}>{description}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    ...SHADOWS.small,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.primary,
  },
  urgentContainer: {
    borderLeftColor: COLORS.error,
  },
  urgentBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: COLORS.error,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  urgentText: {
    color: COLORS.white,
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    marginLeft: 4,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: COLORS.textDark,
    marginBottom: 8,
    marginRight: 80, // Space for the urgent badge
  },
  detailsRow: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  detailText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: COLORS.textLight,
    marginLeft: 4,
  },
  urgentDate: {
    color: COLORS.error,
  },
  className: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.primaryLight,
    marginBottom: 12,
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textDark,
    lineHeight: 22,
  },
});