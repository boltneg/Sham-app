import { useState, useEffect } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, TextInput, Modal, ScrollView, ActivityIndicator } from 'react-native';
import { useAuth } from '@/hooks/useAuth';
import { useData } from '@/hooks/useData';
import { Plus, X, Search, Calendar, FilePlus } from 'lucide-react-native';
import AgendaCard from '@/components/AgendaCard';
import { COLORS } from '@/constants/theme';
import FormButton from '@/components/FormButton';
import DateTimePicker from '@/components/DateTimePicker';

export default function AgendaScreen() {
  const { userData } = useAuth();
  const { classes, subjects, agendas, saveAgenda, getAgendas, isLoading } = useData();
  const [modalVisible, setModalVisible] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [filteredAgendas, setFilteredAgendas] = useState([]);
  const [selectedClassId, setSelectedClassId] = useState('');
  const [selectedSubjectId, setSelectedSubjectId] = useState('');
  const [availableSubjects, setAvailableSubjects] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState(new Date());
  const [error, setError] = useState('');
  
  useEffect(() => {
    if (userData && classes && classes.length > 0) {
      // For students, always use their class
      if (userData.type === 'student' && userData.classId) {
        setSelectedClassId(userData.classId);
        filterSubjects(userData.classId);
      } 
      // For teachers, select first class by default
      else if (userData.type === 'teacher' && classes.length > 0) {
        setSelectedClassId(classes[0].id);
        filterSubjects(classes[0].id);
      }
    }
  }, [userData, classes]);
  
  useEffect(() => {
    if (agendas) {
      filterAgendas();
    }
  }, [agendas, searchText, selectedClassId]);
  
  useEffect(() => {
    if (selectedClassId) {
      loadAgendas();
    }
  }, [selectedClassId]);

  const loadAgendas = async () => {
    await getAgendas(selectedClassId);
  };
  
  const filterSubjects = (classId) => {
    const filtered = subjects.filter(subject => 
      subject.classIds.includes(classId)
    );
    setAvailableSubjects(filtered);
    
    // Auto-select first subject if available
    if (filtered.length > 0) {
      setSelectedSubjectId(filtered[0].id);
    } else {
      setSelectedSubjectId('');
    }
  };
  
  const filterAgendas = () => {
    if (!agendas) return;
    
    let filtered = agendas.filter(agenda => 
      agenda.classId === selectedClassId
    );
    
    if (searchText) {
      filtered = filtered.filter(agenda => 
        agenda.title.toLowerCase().includes(searchText.toLowerCase()) ||
        agenda.description.toLowerCase().includes(searchText.toLowerCase())
      );
    }
    
    setFilteredAgendas(filtered);
  };
  
  const handleCreateAgenda = async () => {
    if (!title || !description || !selectedClassId || !selectedSubjectId) {
      setError('Please fill in all fields');
      return;
    }
    
    try {
      await saveAgenda({
        title,
        description,
        classId: selectedClassId,
        subjectId: selectedSubjectId,
        dueDate: dueDate.toISOString(),
      });
      
      // Reset form
      setTitle('');
      setDescription('');
      setDueDate(new Date());
      setError('');
      setModalVisible(false);
      
      // Reload agendas
      await getAgendas(selectedClassId);
    } catch (err) {
      setError('Failed to create agenda');
      console.error(err);
    }
  };
  
  const closeModal = () => {
    setModalVisible(false);
    setError('');
  };
  
  const getClassName = (classId) => {
    const classObj = classes.find(c => c.id === classId);
    return classObj ? classObj.name : 'Unknown Class';
  };
  
  const getSubjectName = (subjectId) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.name : 'Unknown Subject';
  };
  
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Class Agenda</Text>
        <Text style={styles.subtitle}>
          {userData?.type === 'student' 
            ? 'View all homework for your class' 
            : 'Manage homework assignments'
          }
        </Text>
      </View>
      
      <View style={styles.searchContainer}>
        <Search size={20} color={COLORS.textLight} style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search homework..."
          value={searchText}
          onChangeText={setSearchText}
          placeholderTextColor={COLORS.textLight}
        />
        {searchText ? (
          <TouchableOpacity onPress={() => setSearchText('')}>
            <X size={20} color={COLORS.textLight} />
          </TouchableOpacity>
        ) : null}
      </View>
      
      {/* Class selection for teachers */}
      {userData?.type === 'teacher' && classes.length > 0 && (
        <View style={styles.classesContainer}>
          <Text style={styles.sectionTitle}>Select Class</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.classesScrollView}>
            {classes.map((classItem) => (
              <TouchableOpacity
                key={classItem.id}
                style={[
                  styles.classButton,
                  selectedClassId === classItem.id && styles.classButtonActive
                ]}
                onPress={() => {
                  setSelectedClassId(classItem.id);
                  filterSubjects(classItem.id);
                }}
              >
                <Text
                  style={[
                    styles.classButtonText,
                    selectedClassId === classItem.id && styles.classButtonTextActive
                  ]}
                >
                  {classItem.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}
      
      {userData?.type === 'teacher' && (
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => setModalVisible(true)}
        >
          <Plus size={20} color={COLORS.white} />
          <Text style={styles.addButtonText}>Add New Homework</Text>
        </TouchableOpacity>
      )}
      
      <FlatList
        data={filteredAgendas}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <AgendaCard
            title={item.title}
            description={item.description}
            dueDate={item.dueDate}
            subject={getSubjectName(item.subjectId)}
            className={getClassName(item.classId)}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Calendar size={48} color={COLORS.textLight} />
            <Text style={styles.emptyStateText}>No homework found</Text>
            {userData?.type === 'teacher' && (
              <Text style={styles.emptyStateSubtext}>Create homework assignments for this class</Text>
            )}
          </View>
        }
      />
      
      {/* Create Agenda Modal */}
      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={closeModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add New Homework</Text>
              <TouchableOpacity onPress={closeModal}>
                <X size={24} color={COLORS.textDark} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.modalContent}>
              <Text style={styles.inputLabel}>Title</Text>
              <TextInput
                style={styles.input}
                placeholder="Homework title"
                value={title}
                onChangeText={setTitle}
                placeholderTextColor={COLORS.textLight}
              />
              
              <Text style={styles.inputLabel}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Detailed instructions for the homework"
                value={description}
                onChangeText={setDescription}
                multiline={true}
                numberOfLines={4}
                textAlignVertical="top"
                placeholderTextColor={COLORS.textLight}
              />
              
              <Text style={styles.inputLabel}>Subject</Text>
              <View style={styles.subjectsContainer}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {availableSubjects.map((subject) => (
                    <TouchableOpacity
                      key={subject.id}
                      style={[
                        styles.subjectButton,
                        selectedSubjectId === subject.id && styles.subjectButtonActive
                      ]}
                      onPress={() => setSelectedSubjectId(subject.id)}
                    >
                      <Text
                        style={[
                          styles.subjectButtonText,
                          selectedSubjectId === subject.id && styles.subjectButtonTextActive
                        ]}
                      >
                        {subject.name}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                
                {availableSubjects.length === 0 && (
                  <Text style={styles.noSubjectsText}>
                    No subjects available. Please add subjects to this class first.
                  </Text>
                )}
              </View>
              
              <Text style={styles.inputLabel}>Due Date</Text>
              <DateTimePicker
                date={dueDate}
                onDateChange={setDueDate}
              />
              
              {error ? <Text style={styles.errorText}>{error}</Text> : null}
              
              <FormButton
                onPress={handleCreateAgenda}
                label="Create Homework"
                disabled={availableSubjects.length === 0}
              />
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
  },
  loadingText: {
    marginTop: 16,
    fontFamily: 'Inter-Medium',
    color: COLORS.textDark,
  },
  header: {
    padding: 16,
    paddingTop: 24,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: COLORS.textDark,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textLight,
    marginTop: 4,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    marginHorizontal: 16,
    borderRadius: 8,
    padding: 12,
    marginVertical: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textDark,
  },
  classesContainer: {
    padding: 16,
    paddingTop: 0,
    paddingBottom: 8,
  },
  sectionTitle: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginBottom: 8,
  },
  classesScrollView: {
    flexDirection: 'row',
  },
  classButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: COLORS.backgroundLight,
    marginRight: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  classButtonActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  classButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: COLORS.textDark,
  },
  classButtonTextActive: {
    color: COLORS.white,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    borderRadius: 8,
    paddingVertical: 12,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  addButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.white,
    marginLeft: 8,
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 48,
    backgroundColor: COLORS.white,
    borderRadius: 16,
  },
  emptyStateText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginTop: 16,
  },
  emptyStateSubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 4,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    width: '90%',
    maxWidth: 500,
    maxHeight: '90%',
    backgroundColor: COLORS.white,
    borderRadius: 16,
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  modalTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: COLORS.textDark,
  },
  modalContent: {
    padding: 16,
  },
  inputLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginBottom: 8,
  },
  input: {
    backgroundColor: COLORS.backgroundLight,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textDark,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  textArea: {
    minHeight: 100,
  },
  subjectsContainer: {
    marginBottom: 16,
  },
  subjectButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: COLORS.backgroundLight,
    marginRight: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  subjectButtonActive: {
    backgroundColor: COLORS.secondary,
    borderColor: COLORS.secondary,
  },
  subjectButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: COLORS.textDark,
  },
  subjectButtonTextActive: {
    color: COLORS.white,
  },
  noSubjectsText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.textLight,
    fontStyle: 'italic',
    marginTop: 8,
  },
  errorText: {
    color: COLORS.error,
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    marginBottom: 16,
  },
});