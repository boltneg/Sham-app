import { StyleSheet, TouchableOpacity, Text, ActivityIndicator } from 'react-native';
import { COLORS } from '@/constants/theme';

interface FormButtonProps {
  onPress: () => void;
  label: string;
  isLoading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'outline';
}

export default function FormButton({ 
  onPress, 
  label, 
  isLoading = false, 
  disabled = false,
  variant = 'primary'
}: FormButtonProps) {
  const getButtonStyles = () => {
    if (disabled) {
      return styles.buttonDisabled;
    }
    
    switch (variant) {
      case 'secondary':
        return styles.buttonSecondary;
      case 'outline':
        return styles.buttonOutline;
      default:
        return styles.button;
    }
  };
  
  const getTextStyles = () => {
    if (disabled) {
      return styles.buttonTextDisabled;
    }
    
    switch (variant) {
      case 'outline':
        return styles.buttonTextOutline;
      default:
        return styles.buttonText;
    }
  };
  
  return (
    <TouchableOpacity
      style={getButtonStyles()}
      onPress={onPress}
      disabled={isLoading || disabled}
    >
      {isLoading ? (
        <ActivityIndicator size="small" color={variant === 'outline' ? COLORS.primary : COLORS.white} />
      ) : (
        <Text style={getTextStyles()}>{label}</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: COLORS.primary,
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonSecondary: {
    backgroundColor: COLORS.secondary,
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonOutline: {
    backgroundColor: 'transparent',
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  buttonDisabled: {
    backgroundColor: COLORS.backgroundLight,
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: COLORS.white,
    fontFamily: 'Inter-Medium',
    fontSize: 16,
  },
  buttonTextOutline: {
    color: COLORS.primary,
    fontFamily: 'Inter-Medium',
    fontSize: 16,
  },
  buttonTextDisabled: {
    color: COLORS.textLight,
    fontFamily: 'Inter-Medium',
    fontSize: 16,
  },
});