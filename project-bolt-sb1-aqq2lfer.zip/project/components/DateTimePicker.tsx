import { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Platform } from 'react-native';
import { Calendar } from 'lucide-react-native';
import { COLORS } from '@/constants/theme';
import DateTimePicker from '@react-native-community/datetimepicker';

interface CustomDateTimePickerProps {
  date: Date;
  onDateChange: (date: Date) => void;
}

export default function CustomDateTimePicker({ date, onDateChange }: CustomDateTimePickerProps) {
  const [show, setShow] = useState(false);

  const onChange = (event: any, selectedDate?: Date) => {
    const currentDate = selectedDate || date;
    if (Platform.OS !== 'web') {
      setShow(Platform.OS === 'ios');
    }
    onDateChange(currentDate);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const showDatePicker = () => {
    setShow(true);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.dateButton} onPress={showDatePicker}>
        <Calendar size={20} color={COLORS.primary} />
        <Text style={styles.dateText}>{formatDate(date)}</Text>
      </TouchableOpacity>

      {show && Platform.OS !== 'web' && (
        <DateTimePicker
          testID="dateTimePicker"
          value={date}
          mode="date"
          display="default"
          onChange={onChange}
          minimumDate={new Date()}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.backgroundLight,
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  dateText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginLeft: 8,
  },
});