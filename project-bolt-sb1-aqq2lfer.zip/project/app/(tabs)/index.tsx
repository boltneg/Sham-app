import { useEffect, useState } from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, FlatList, ActivityIndicator } from 'react-native';
import { useAuth } from '@/hooks/useAuth';
import { useData } from '@/hooks/useData';
import { Calendar, BookOpen, Clock } from 'lucide-react-native';
import AgendaCard from '@/components/AgendaCard';
import { COLORS } from '@/constants/theme';
import { formatDate } from '@/utils/dateUtils';

export default function HomeScreen() {
  const { userData } = useAuth();
  const { classes, subjects, getUpcomingAgendas, isLoading } = useData();
  const [upcomingAgendas, setUpcomingAgendas] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);

  useEffect(() => {
    if (userData) {
      if (userData.type === 'student' && userData.classId) {
        setSelectedClass(userData.classId);
        loadAgendas(userData.classId);
      } else if (userData.type === 'teacher') {
        // For teachers, we'll show first class by default
        if (classes && classes.length > 0) {
          setSelectedClass(classes[0].id);
          loadAgendas(classes[0].id);
        }
      }
    }
  }, [userData, classes]);

  const loadAgendas = async (classId) => {
    const agendas = await getUpcomingAgendas(classId);
    setUpcomingAgendas(agendas);
  };

  const getClassName = (classId) => {
    const classObj = classes.find(c => c.id === classId);
    return classObj ? classObj.name : 'Unknown Class';
  };

  const getSubjectName = (subjectId) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.name : 'Unknown Subject';
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.welcomeText}>
          Welcome, <Text style={styles.username}>{userData?.username || 'User'}</Text>
        </Text>
        <Text style={styles.dateText}>{formatDate(new Date())}</Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <Calendar size={24} color={COLORS.primary} />
          </View>
          <Text style={styles.statNumber}>{upcomingAgendas.length}</Text>
          <Text style={styles.statLabel}>Upcoming Tasks</Text>
        </View>

        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <BookOpen size={24} color={COLORS.secondary} />
          </View>
          <Text style={styles.statNumber}>{subjects.length}</Text>
          <Text style={styles.statLabel}>Subjects</Text>
        </View>

        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <Clock size={24} color={COLORS.accent} />
          </View>
          <Text style={styles.statNumber}>
            {userData?.type === 'student' ? '1' : classes.length}
          </Text>
          <Text style={styles.statLabel}>Classes</Text>
        </View>
      </View>

      {/* Classes Selection (only for teachers) */}
      {userData?.type === 'teacher' && classes.length > 0 && (
        <View style={styles.classesContainer}>
          <Text style={styles.sectionTitle}>Classes</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.classesScrollView}>
            {classes.map((classItem) => (
              <TouchableOpacity
                key={classItem.id}
                style={[
                  styles.classButton,
                  selectedClass === classItem.id && styles.classButtonActive
                ]}
                onPress={() => {
                  setSelectedClass(classItem.id);
                  loadAgendas(classItem.id);
                }}
              >
                <Text
                  style={[
                    styles.classButtonText,
                    selectedClass === classItem.id && styles.classButtonTextActive
                  ]}
                >
                  {classItem.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      <View style={styles.agendasContainer}>
        <Text style={styles.sectionTitle}>
          {userData?.type === 'student' 
            ? 'Your Upcoming Homework' 
            : `Homework for ${getClassName(selectedClass)}`
          }
        </Text>
        
        {upcomingAgendas.length > 0 ? (
          upcomingAgendas.map((agenda) => (
            <AgendaCard
              key={agenda.id}
              title={agenda.title}
              description={agenda.description}
              dueDate={agenda.dueDate}
              subject={getSubjectName(agenda.subjectId)}
              className={getClassName(agenda.classId)}
            />
          ))
        ) : (
          <View style={styles.emptyState}>
            <Calendar size={48} color={COLORS.textLight} />
            <Text style={styles.emptyStateText}>No upcoming homework!</Text>
            <Text style={styles.emptyStateSubtext}>Enjoy your free time</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
  },
  loadingText: {
    marginTop: 16,
    fontFamily: 'Inter-Medium',
    color: COLORS.textDark,
  },
  header: {
    padding: 16,
    paddingTop: 24,
  },
  welcomeText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: COLORS.textDark,
  },
  username: {
    fontFamily: 'Inter-Bold',
    color: COLORS.primary,
  },
  dateText: {
    fontFamily: 'Inter-Medium',
    fontSize: 20,
    color: COLORS.textDark,
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
  },
  statCard: {
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: 16,
    flex: 1,
    marginHorizontal: 4,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  statIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.backgroundLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statNumber: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: COLORS.textDark,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: COLORS.textLight,
    marginTop: 4,
  },
  classesContainer: {
    padding: 16,
    paddingBottom: 8,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: COLORS.textDark,
    marginBottom: 12,
  },
  classesScrollView: {
    flexDirection: 'row',
  },
  classButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: COLORS.backgroundLight,
    marginRight: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  classButtonActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  classButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: COLORS.textDark,
  },
  classButtonTextActive: {
    color: COLORS.white,
  },
  agendasContainer: {
    padding: 16,
    paddingTop: 8,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 48,
    backgroundColor: COLORS.white,
    borderRadius: 16,
    marginTop: 16,
  },
  emptyStateText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginTop: 16,
  },
  emptyStateSubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 4,
  },
});