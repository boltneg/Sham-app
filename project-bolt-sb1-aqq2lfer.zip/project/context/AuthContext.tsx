import { createContext, useState, useEffect, ReactNode } from 'react';
import * as SecureStore from 'expo-secure-store';
import { Alert } from 'react-native';
import { readJSONFile, writeJSONFile } from '@/utils/fileUtils';

interface User {
  id: string;
  username: string;
  type: 'student' | 'teacher';
  classId?: string;
  className?: string;
}

interface AuthContextType {
  isLoggedIn: boolean;
  userData: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  register: (username: string, password: string, userType: 'student' | 'teacher') => Promise<boolean>;
  logout: () => void;
  updateUserData: (data: Partial<User>) => Promise<void>;
}

export const AuthContext = createContext<AuthContextType>({
  isLoggedIn: false,
  userData: null,
  login: async () => false,
  register: async () => false,
  logout: () => {},
  updateUserData: async () => {},
});

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userData, setUserData] = useState<User | null>(null);
  
  useEffect(() => {
    // Check if user is already logged in on app startup
    loadUserData();
  }, []);
  
  const loadUserData = async () => {
    try {
      const userJson = await SecureStore.getItemAsync('user');
      if (userJson) {
        const user = JSON.parse(userJson);
        setUserData(user);
        setIsLoggedIn(true);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };
  
  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      // Read users data from JSON file
      const users = await readJSONFile('users.json', []);
      
      // Find user with matching username and password
      const user = users.find((u: any) => 
        u.username === username && u.password === password
      );
      
      if (user) {
        // Create user data object without sensitive info
        const userData: User = {
          id: user.id,
          username: user.username,
          type: user.type,
          classId: user.classId,
          className: user.className,
        };
        
        // Save user data to secure storage
        await SecureStore.setItemAsync('user', JSON.stringify(userData));
        
        // Update state
        setUserData(userData);
        setIsLoggedIn(true);
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error during login:', error);
      return false;
    }
  };
  
  const register = async (
    username: string, 
    password: string, 
    userType: 'student' | 'teacher'
  ): Promise<boolean> => {
    try {
      // Read existing users
      const users = await readJSONFile('users.json', []);
      
      // Check if username already exists
      const userExists = users.some((u: any) => u.username === username);
      if (userExists) {
        return false;
      }
      
      // Create new user object
      const newUser = {
        id: Date.now().toString(),
        username,
        password,
        type: userType,
        classId: null,
        className: null,
      };
      
      // Add new user to users array
      users.push(newUser);
      
      // Save updated users array
      await writeJSONFile('users.json', users);
      
      return true;
    } catch (error) {
      console.error('Error during registration:', error);
      return false;
    }
  };
  
  const logout = () => {
    // Remove user data from secure storage
    SecureStore.deleteItemAsync('user');
    
    // Update state
    setUserData(null);
    setIsLoggedIn(false);
  };
  
  const updateUserData = async (data: Partial<User>): Promise<void> => {
    try {
      if (!userData) return;
      
      // Update user data in state
      const updatedUserData = { ...userData, ...data };
      setUserData(updatedUserData);
      
      // Save updated user data to secure storage
      await SecureStore.setItemAsync('user', JSON.stringify(updatedUserData));
      
      // Update user in JSON file (except password)
      const users = await readJSONFile('users.json', []);
      const updatedUsers = users.map((user: any) => {
        if (user.id === userData.id) {
          return { ...user, ...data };
        }
        return user;
      });
      
      await writeJSONFile('users.json', updatedUsers);
    } catch (error) {
      console.error('Error updating user data:', error);
      Alert.alert('Error', 'Failed to update user data');
    }
  };
  
  return (
    <AuthContext.Provider value={{ 
      isLoggedIn, 
      userData, 
      login, 
      register, 
      logout,
      updateUserData,
    }}>
      {children}
    </AuthContext.Provider>
  );
}