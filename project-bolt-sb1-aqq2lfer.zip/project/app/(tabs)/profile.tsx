import { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Switch, Alert, ScrollView, Share, Platform } from 'react-native';
import { useAuth } from '@/hooks/useAuth';
import { useTheme } from '@/hooks/useTheme';
import { useData } from '@/hooks/useData';
import { LogOut, User, Moon, Sun, HelpCircle, Download, Share2 } from 'lucide-react-native';
import { COLORS } from '@/constants/theme';
import * as Sharing from 'expo-sharing';
import * as Print from 'expo-print';
import * as FileSystem from 'expo-file-system';

export default function ProfileScreen() {
  const { userData, logout } = useAuth();
  const { darkMode, toggleDarkMode } = useTheme();
  const { exportAgendas } = useData();
  const [isExporting, setIsExporting] = useState(false);

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', onPress: () => logout(), style: 'destructive' }
      ]
    );
  };

  const handleShareApp = async () => {
    try {
      await Share.share({
        message: 'Check out Agenda Hub, the school agenda management app!',
        title: 'Agenda Hub'
      });
    } catch (error) {
      console.error('Error sharing app:', error);
    }
  };

  const handleExportAgendas = async () => {
    try {
      setIsExporting(true);
      
      // Get agenda data for export
      const exportData = await exportAgendas();
      
      // Generate PDF from agenda data
      const html = `
        <html>
          <head>
            <style>
              body { font-family: sans-serif; margin: 40px; }
              h1 { color: #1E40AF; text-align: center; }
              h2 { color: #0F766E; margin-top: 30px; }
              .agenda-item { 
                border: 1px solid #E5E7EB; 
                border-radius: 8px; 
                padding: 15px; 
                margin-bottom: 15px; 
                background-color: #F9FAFB;
              }
              .agenda-title { font-size: 18px; font-weight: bold; margin-bottom: 5px; }
              .agenda-details { color: #6B7280; margin-bottom: 10px; }
              .agenda-description { margin-top: 10px; }
            </style>
          </head>
          <body>
            <h1>Agenda Hub - Class Agendas</h1>
            <p style="text-align: center;">Exported on ${new Date().toLocaleString()}</p>
            
            ${exportData.map(group => `
              <h2>${group.className}</h2>
              ${group.agendas.map(agenda => `
                <div class="agenda-item">
                  <div class="agenda-title">${agenda.title}</div>
                  <div class="agenda-details">
                    Subject: ${agenda.subject} | Due: ${new Date(agenda.dueDate).toLocaleDateString()}
                  </div>
                  <div class="agenda-description">${agenda.description}</div>
                </div>
              `).join('')}
            `).join('')}
          </body>
        </html>
      `;
      
      const { uri } = await Print.printToFileAsync({ html });
      
      // Create a more user-friendly filename
      const filename = FileSystem.documentDirectory + 'AgendaHub_Export.pdf';
      await FileSystem.moveAsync({
        from: uri,
        to: filename,
      });
      
      // Share the PDF file
      if (Platform.OS === 'ios') {
        await Sharing.shareAsync(filename);
      } else {
        await Sharing.shareAsync(filename, {
          mimeType: 'application/pdf',
          dialogTitle: 'Export Agendas',
        });
      }
    } catch (error) {
      console.error('Error exporting agendas:', error);
      Alert.alert('Export Failed', 'There was an error exporting the agendas.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.profileHeader}>
        <View style={styles.avatarContainer}>
          <User size={60} color={COLORS.white} />
        </View>
        <Text style={styles.username}>{userData?.username || 'User'}</Text>
        <Text style={styles.userType}>
          {userData?.type === 'teacher' ? 'Teacher' : 'Student'}
          {userData?.type === 'student' && userData?.classId ? 
            ` - ${userData.className || 'Class Member'}` : ''}
        </Text>
      </View>
      
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Preferences</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingLabelContainer}>
            {darkMode ? (
              <Moon size={24} color={COLORS.textDark} />
            ) : (
              <Sun size={24} color={COLORS.textDark} />
            )}
            <Text style={styles.settingLabel}>Dark Mode</Text>
          </View>
          <Switch
            value={darkMode}
            onValueChange={toggleDarkMode}
            trackColor={{ false: COLORS.border, true: COLORS.primaryLight }}
            thumbColor={darkMode ? COLORS.primary : COLORS.white}
          />
        </View>
      </View>
      
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Tools</Text>
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={handleExportAgendas}
          disabled={isExporting}
        >
          <Download size={20} color={COLORS.white} />
          <Text style={styles.actionButtonText}>
            {isExporting ? 'Exporting...' : 'Export Agendas as PDF'}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionButton, { backgroundColor: COLORS.secondary }]}
          onPress={handleShareApp}
        >
          <Share2 size={20} color={COLORS.white} />
          <Text style={styles.actionButtonText}>Share App</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>Help & Support</Text>
        
        <TouchableOpacity style={styles.menuItem}>
          <HelpCircle size={24} color={COLORS.textDark} />
          <Text style={styles.menuItemText}>Help & FAQs</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <HelpCircle size={24} color={COLORS.textDark} />
          <Text style={styles.menuItemText}>Contact Support</Text>
        </TouchableOpacity>
      </View>
      
      <TouchableOpacity 
        style={styles.logoutButton}
        onPress={handleLogout}
      >
        <LogOut size={20} color={COLORS.error} />
        <Text style={styles.logoutButtonText}>Logout</Text>
      </TouchableOpacity>
      
      <Text style={styles.versionText}>Agenda Hub v1.0.0</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: 32,
    paddingHorizontal: 16,
    backgroundColor: COLORS.primary,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  username: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: COLORS.white,
    marginBottom: 4,
  },
  userType: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  sectionContainer: {
    padding: 16,
    marginBottom: 8,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: COLORS.textDark,
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  settingLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginLeft: 12,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  menuItemText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.textDark,
    marginLeft: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    borderRadius: 8,
    paddingVertical: 14,
    marginBottom: 12,
  },
  actionButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.white,
    marginLeft: 8,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderRadius: 8,
    paddingVertical: 14,
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 24,
  },
  logoutButtonText: {
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    color: COLORS.error,
    marginLeft: 8,
  },
  versionText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: COLORS.textLight,
    textAlign: 'center',
    marginBottom: 32,
  },
});