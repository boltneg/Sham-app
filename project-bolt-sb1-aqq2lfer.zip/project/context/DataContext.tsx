import { createContext, useState, useEffect, ReactNode, useRef } from 'react';
import { Alert } from 'react-native';
import { readJSONFile, writeJSONFile } from '@/utils/fileUtils';
import { supabaseClient } from '@/services/supabase';
import { useAuth } from '@/hooks/useAuth';

interface Class {
  id: string;
  name: string;
}

interface Subject {
  id: string;
  name: string;
  classIds: string[];
}

interface Agenda {
  id: string;
  title: string;
  description: string;
  classId: string;
  subjectId: string;
  dueDate: string;
  createdBy: string;
  createdAt: string;
}

interface DataContextType {
  classes: Class[];
  subjects: Subject[];
  agendas: Agenda[];
  isLoading: boolean;
  saveClass: (name: string) => Promise<Class>;
  saveSubject: (name: string, classId: string) => Promise<Subject>;
  saveAgenda: (agenda: Omit<Agenda, 'id' | 'createdBy' | 'createdAt'>) => Promise<Agenda>;
  getAgendas: (classId: string) => Promise<Agenda[]>;
  getUpcomingAgendas: (classId: string) => Promise<Agenda[]>;
  updateUserClass: (classId: string) => Promise<void>;
  exportAgendas: () => Promise<any[]>;
}

export const DataContext = createContext<DataContextType>({
  classes: [],
  subjects: [],
  agendas: [],
  isLoading: false,
  saveClass: async () => ({} as Class),
  saveSubject: async () => ({} as Subject),
  saveAgenda: async () => ({} as Agenda),
  getAgendas: async () => [],
  getUpcomingAgendas: async () => [],
  updateUserClass: async () => {},
  exportAgendas: async () => [],
});

interface DataProviderProps {
  children: ReactNode;
}

export function DataProvider({ children }: DataProviderProps) {
  const [classes, setClasses] = useState<Class[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [agendas, setAgendas] = useState<Agenda[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Store a reference to the initialized Supabase client
  const supabaseInitialized = useRef(false);
  
  const { userData, updateUserData } = useAuth();
  
  useEffect(() => {
    loadInitialData();
  }, []);
  
  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      // Initialize example data if it doesn't exist yet
      await initializeExampleData();
      
      // Load classes and subjects from JSON files
      const loadedClasses = await readJSONFile('classes.json', []);
      const loadedSubjects = await readJSONFile('subjects.json', []);
      
      setClasses(loadedClasses);
      setSubjects(loadedSubjects);
      
      // Initialize Supabase connection
      await initializeSupabase();
      
      // If user is logged in, load their class's agendas
      if (userData && userData.classId) {
        await getAgendas(userData.classId);
      }
    } catch (error) {
      console.error('Error loading initial data:', error);
      Alert.alert('Error', 'Failed to load initial data');
    } finally {
      setIsLoading(false);
    }
  };
  
  const initializeExampleData = async () => {
    // Check if classes.json exists, if not create with example data
    const existingClasses = await readJSONFile('classes.json', null);
    if (!existingClasses) {
      const exampleClasses = Array.from({ length: 12 }, (_, i) => ({
        id: `class_${i + 1}`,
        name: `Class ${i + 1}`,
      }));
      await writeJSONFile('classes.json', exampleClasses);
    }
    
    // Check if subjects.json exists, if not create with example data
    const existingSubjects = await readJSONFile('subjects.json', null);
    if (!existingSubjects) {
      const exampleSubjects = [
        {
          id: 'subject_1',
          name: 'Mathematics',
          classIds: Array.from({ length: 12 }, (_, i) => `class_${i + 1}`),
        },
        {
          id: 'subject_2',
          name: 'Science',
          classIds: Array.from({ length: 12 }, (_, i) => `class_${i + 1}`),
        },
        {
          id: 'subject_3',
          name: 'English',
          classIds: Array.from({ length: 12 }, (_, i) => `class_${i + 1}`),
        },
        {
          id: 'subject_4',
          name: 'History',
          classIds: Array.from({ length: 12 }, (_, i) => `class_${i + 1}`),
        },
        {
          id: 'subject_5',
          name: 'Geography',
          classIds: Array.from({ length: 12 }, (_, i) => `class_${i + 1}`),
        },
      ];
      await writeJSONFile('subjects.json', exampleSubjects);
    }
    
    // Check if users.json exists, if not create with example data
    const existingUsers = await readJSONFile('users.json', null);
    if (!existingUsers) {
      const exampleUsers = [
        {
          id: 'teacher_1',
          username: 'teacher',
          password: 'password',
          type: 'teacher',
        },
        {
          id: 'student_1',
          username: 'student',
          password: 'password',
          type: 'student',
          classId: 'class_1',
          className: 'Class 1',
        },
      ];
      await writeJSONFile('users.json', exampleUsers);
    }
  };
  
  const initializeSupabase = async () => {
    if (supabaseInitialized.current) return;
    
    try {
      // For local development, we'll use a simple mock
      // In a real app, you would connect to Supabase here
      supabaseInitialized.current = true;
    } catch (error) {
      console.error('Error initializing Supabase:', error);
    }
  };
  
  const saveClass = async (name: string): Promise<Class> => {
    try {
      const newClass: Class = {
        id: `class_${Date.now()}`,
        name,
      };
      
      const updatedClasses = [...classes, newClass];
      await writeJSONFile('classes.json', updatedClasses);
      
      setClasses(updatedClasses);
      return newClass;
    } catch (error) {
      console.error('Error saving class:', error);
      throw new Error('Failed to save class');
    }
  };
  
  const saveSubject = async (name: string, classId: string): Promise<Subject> => {
    try {
      // Check if subject already exists
      const existingSubject = subjects.find(s => 
        s.name.toLowerCase() === name.toLowerCase()
      );
      
      if (existingSubject) {
        // If subject exists but doesn't have this class, add the class
        if (!existingSubject.classIds.includes(classId)) {
          const updatedSubject = {
            ...existingSubject,
            classIds: [...existingSubject.classIds, classId],
          };
          
          const updatedSubjects = subjects.map(s => 
            s.id === existingSubject.id ? updatedSubject : s
          );
          
          await writeJSONFile('subjects.json', updatedSubjects);
          setSubjects(updatedSubjects);
          
          return updatedSubject;
        }
        
        return existingSubject;
      }
      
      // Create new subject
      const newSubject: Subject = {
        id: `subject_${Date.now()}`,
        name,
        classIds: [classId],
      };
      
      const updatedSubjects = [...subjects, newSubject];
      await writeJSONFile('subjects.json', updatedSubjects);
      
      setSubjects(updatedSubjects);
      return newSubject;
    } catch (error) {
      console.error('Error saving subject:', error);
      throw new Error('Failed to save subject');
    }
  };
  
  const saveAgenda = async (
    agendaData: Omit<Agenda, 'id' | 'createdBy' | 'createdAt'>
  ): Promise<Agenda> => {
    try {
      if (!userData) throw new Error('User not logged in');
      
      const newAgenda: Agenda = {
        ...agendaData,
        id: `agenda_${Date.now()}`,
        createdBy: userData.id,
        createdAt: new Date().toISOString(),
      };
      
      // In a real app, we would save to Supabase here
      // For now, we'll just use our local state
      
      // First, get any existing agendas stored in our "database"
      const existingAgendas = await readJSONFile('agendas.json', []);
      
      // Add the new agenda
      const updatedAgendas = [...existingAgendas, newAgenda];
      
      // Save back to our "database"
      await writeJSONFile('agendas.json', updatedAgendas);
      
      // Update local state
      setAgendas(prevAgendas => [...prevAgendas, newAgenda]);
      
      return newAgenda;
    } catch (error) {
      console.error('Error saving agenda:', error);
      throw new Error('Failed to save agenda');
    }
  };
  
  const getAgendas = async (classId: string): Promise<Agenda[]> => {
    try {
      // In a real app, we would fetch from Supabase here
      const allAgendas = await readJSONFile('agendas.json', []);
      
      // Filter to only show agendas for the specified class
      const filteredAgendas = allAgendas.filter(
        (agenda: Agenda) => agenda.classId === classId
      );
      
      // Sort by due date (most recent first)
      filteredAgendas.sort((a: Agenda, b: Agenda) => 
        new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
      );
      
      setAgendas(filteredAgendas);
      return filteredAgendas;
    } catch (error) {
      console.error('Error getting agendas:', error);
      return [];
    }
  };
  
  const getUpcomingAgendas = async (classId: string): Promise<Agenda[]> => {
    try {
      const allAgendas = await getAgendas(classId);
      
      // Filter to only show upcoming agendas (due date is in the future)
      const now = new Date();
      const upcomingAgendas = allAgendas.filter(
        (agenda) => new Date(agenda.dueDate) >= now
      );
      
      // Sort by due date (soonest first)
      upcomingAgendas.sort((a, b) => 
        new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
      );
      
      return upcomingAgendas;
    } catch (error) {
      console.error('Error getting upcoming agendas:', error);
      return [];
    }
  };
  
  const updateUserClass = async (classId: string): Promise<void> => {
    try {
      if (!userData) return;
      
      // Find the class name
      const classObj = classes.find(c => c.id === classId);
      if (!classObj) throw new Error('Class not found');
      
      // Update user data with class info
      await updateUserData({
        classId,
        className: classObj.name,
      });
      
      // Load agendas for the selected class
      await getAgendas(classId);
    } catch (error) {
      console.error('Error updating user class:', error);
      throw new Error('Failed to update user class');
    }
  };
  
  const exportAgendas = async (): Promise<any[]> => {
    try {
      if (!userData) throw new Error('User not logged in');
      
      let classesToExport = [];
      let allAgendas = [];
      
      // For students, only export their class
      if (userData.type === 'student' && userData.classId) {
        classesToExport = [userData.classId];
        allAgendas = await getAgendas(userData.classId);
      } 
      // For teachers, export all classes
      else if (userData.type === 'teacher') {
        classesToExport = classes.map(c => c.id);
        
        // Get agendas for all classes
        const agendasJson = await readJSONFile('agendas.json', []);
        allAgendas = agendasJson;
      }
      
      // Group agendas by class
      const groupedAgendas = [];
      
      for (const classId of classesToExport) {
        const classObj = classes.find(c => c.id === classId);
        if (!classObj) continue;
        
        const classAgendas = allAgendas.filter(
          (agenda: Agenda) => agenda.classId === classId
        );
        
        // Add subject names to agendas
        const formattedAgendas = classAgendas.map((agenda: Agenda) => {
          const subject = subjects.find(s => s.id === agenda.subjectId);
          return {
            ...agenda,
            subject: subject ? subject.name : 'Unknown Subject',
          };
        });
        
        // Sort by due date
        formattedAgendas.sort((a, b) => 
          new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
        );
        
        groupedAgendas.push({
          className: classObj.name,
          agendas: formattedAgendas,
        });
      }
      
      return groupedAgendas;
    } catch (error) {
      console.error('Error exporting agendas:', error);
      throw new Error('Failed to export agendas');
    }
  };
  
  return (
    <DataContext.Provider value={{
      classes,
      subjects,
      agendas,
      isLoading,
      saveClass,
      saveSubject,
      saveAgenda,
      getAgendas,
      getUpcomingAgendas,
      updateUserClass,
      exportAgendas,
    }}>
      {children}
    </DataContext.Provider>
  );
}